const express = require('express');
const axios = require('axios');
const path = require('path');
const cors = require('cors');
const xml2js = require('xml2js'); // xml2js 모듈 추가

const app = express();

// 서울시 API 인증키
const apiKey = '42494a5171696f6b37374b474c5a61'; // 발급받은 인증키로 변경

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/search', async (req, res) => {
    const query = (req.query.query || '볼거리 맛집').trim(); // 앞뒤 공백 제거
    const display = 1000;

    try {
        // 서울 관광 명소 API 요청
        const localResponse = await axios.get(`http://openapi.seoul.go.kr:8088/${apiKey}/xml/TbVwAttractions/1/${display}/`, {
            headers: {
                'Content-Type': 'application/xml',
            }
        });

        // XML 응답을 JSON으로 변환
        const parser = new xml2js.Parser();
        parser.parseString(localResponse.data, (err, result) => {
            if (err) {
                console.error("XML parse error:", err);
                return res.status(500).send("XML parsing error");
            }

            // 응답에서 필요한 데이터 파싱
            let items = result.TbVwAttractions.row;

            // 한국어(ko)와 영어(en)만 필터링
            items = items.filter(item => {
                return item.LANG_CODE_ID[0] === 'ko' || item.LANG_CODE_ID[0] === 'en';
            });

            // 사용자가 입력한 검색어와 일치하는 항목만 필터링 (TAG 필드 사용)
            const filteredItems = items.filter(item => {
                const tags = item.TAG ? item.TAG[0] : ''; // TAG가 존재할 경우 사용
                return tags.includes(query); // TAG에 검색어가 포함되는지 확인
            });

            // 필터링된 결과 반환
            res.json({ items: filteredItems });
        });
    } catch (error) {
        console.error("API call error:", error);
        res.status(500).send("API call error");
    }
});


app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});

const searchButton = document.getElementById('searchButton');
const resultsContainer = document.getElementById('results');

searchButton.addEventListener('click', async () => {
    const query = document.getElementById('searchInput').value;
    const url = `http://localhost:3000/api/search?query=${encodeURIComponent(query)}`; // 로컬 서버로 요청

    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('검색에 실패했습니다.');
        }
        const data = await response.json();
        displayResults(data.items);
    } catch (error) {
        console.error('오류 발생:', error);
        resultsContainer.innerHTML = `<p>${error.message}</p>`;
    }
});
